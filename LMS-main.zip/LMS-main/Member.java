package model;

public class Member {
    private int memberId;
    private String name;
    private String email;
    private String membershipId;

    // Constructor, getters, setters, and toString method
}

