package model;

import java.util.Date;

public class Transaction {
    private int transactionId;
    private int bookId;
    private int memberId;
    private Date borrowDate;
    private Date returnDate;

    // Constructor, getters, setters, and toString method
}
