package model;

public class Book {
    private int bookId;
    private String title;
    private String author;
    private String isbn;
    private String genre;
    private int availableCopies;

    // Constructor, getters, setters, and toString method
}
